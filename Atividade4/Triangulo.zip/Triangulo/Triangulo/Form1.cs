﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = ""; 
            txtLadoB.Text = ""; 
            txtLadoC.Text = "";
            //private void button2_Click(object sender, EventArgs e) {  } private void btnCalcular_Click(object sender, EventArgs e) { int ladoA, ladoB, ladoC; ladoA = Convert.ToInt(txtLadoA.Text); ladoB = ladoC = } } }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;
            ladoA = Convert.ToDouble(txtLadoA.Text);
            ladoB = Convert.ToDouble(txtLadoB.Text);
            ladoC = Convert.ToDouble(txtLadoC.Text);
            if (ladoA == ladoB || ladoA==ladoC || ladoB==ladoA || ladoB==ladoC || ladoC==ladoB || ladoC==ladoA)
            {
                txtResultado.Text = " Triângulo ISÓCELES";
            }else if(ladoA==ladoC  && ladoA == ladoB && ladoB == ladoA && ladoB == ladoC && ladoC == ladoA && ladoC== ladoB)
            {
                txtResultado.Text = " Triângulo EQUILÁTERO";
            }else if ((ladoA-ladoB)< ladoC && ladoC < (ladoA + ladoB)){
                txtResultado.Text = " Triângulo ESCALENO";
            }
            else
            {
                MessageBox.Show("Valores incorretos, insira novamente!");
            }
        }
    }
}
