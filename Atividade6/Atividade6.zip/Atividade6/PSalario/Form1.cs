namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string Nome         = Convert.ToString(txtNome.Text);
            double salarioBruto = Convert.ToDouble(mskSalBruto.Text);
            int    qtdFilhos    = Convert.ToInt32(numQtdFilhos.Text);
            double descontoInss = 0;
            double descontoIrpf = 0;
            double salFamilia   = 0;
            double salLiquido   = 0;
            string sexo;
            string estadoCivil;

            grbDescontos.Visible = true;
            //aliquota inss
            if (salarioBruto <= 800.47){

                txtAliquotaInss.Text = "7.65%";
                descontoInss = salarioBruto * 0.0765;
                txtDescontoInss.Text = Convert.ToString(descontoInss);

            }
            else if(salarioBruto >= 800.48 && salarioBruto <= 1050){

                txtAliquotaInss.Text = "8.65%";
                descontoInss = salarioBruto * 0.0865;
                txtDescontoInss.Text = Convert.ToString(descontoInss);

            }
            else if(salarioBruto >= 1050.01 && salarioBruto <= 1400.77){

                txtAliquotaInss.Text = "9.00%";
                descontoInss = salarioBruto * 0.9;
                txtDescontoInss.Text = Convert.ToString(descontoInss);

            }
            else if(salarioBruto >= 1400.78 && salarioBruto <= 2801.56){

                txtAliquotaInss.Text = "11.00%";
                descontoInss = salarioBruto * 0.11;
                txtDescontoInss.Text = Convert.ToString(descontoInss);

            }
            else if(salarioBruto > 2801.56){
        
                txtAliquotaInss.Text = "teto";
                descontoInss = 308.17;
                txtDescontoInss.Text = Convert.ToString(descontoInss);
            }
            

            //aliquota irpf
            if(salarioBruto <= 1257.12)
            {
                txtAliquotaIrpf.Text = "isento";
                descontoIrpf = 0;
                txtDescontoIrpf.Text = Convert.ToString(descontoIrpf);
            }
            else if(salarioBruto >= 1257.13 && salarioBruto <= 2512.08)
            {
                txtAliquotaIrpf.Text = "15.00%";
                descontoIrpf = salarioBruto * 0.15;
                txtDescontoIrpf.Text = Convert.ToString(descontoIrpf);
            }
            else if(salarioBruto > 2512.08)
            {
                txtAliquotaIrpf.Text = "27.5%";
                descontoIrpf = (27.5 / 100) * salarioBruto;
                txtDescontoIrpf.Text = Convert.ToString(descontoIrpf);
            }

            


            //salario familia
            if (salarioBruto <= 435.32){
                salFamilia = qtdFilhos * 22.33;
            }else if(salarioBruto >= 435.53 && salarioBruto <= 654.61)
            {
                salFamilia = qtdFilhos * 15.74;
                txtSalFamila.Text = Convert.ToString(salFamilia);
            }
            else if(salarioBruto > 654.61)
            {
                salFamilia = 0;
                txtSalFamila.Text = Convert.ToString(salFamilia);
            }

            salLiquido = (salarioBruto - descontoInss - descontoIrpf) + salFamilia;
            txtSalLiquido.Text = Convert.ToString(salLiquido);

            //sexo
            if(radF.Checked == true)
            {
                sexo = "feminino";
            }else if(radM.Checked == true)
            {
                sexo = "masculino";
            }

            //estado civil
            if(radCasado.Checked == true)
            {
                estadoCivil = "casado";
            }else if(radSolteiro.Checked == true)
            {
                estadoCivil = "solteiro";
            }

            lblDados.Text = "Funcion�rio: " + Nome +  ", Qtd de filhos: " + qtdFilhos + " Sal�rio Liquido: " + salLiquido;
           
    }
        private void button1_Click(object sender, EventArgs e)
        {
            grbDescontos.Visible = false;
            txtNome.Text = "";
            mskSalBruto.Text = "";
            numQtdFilhos.Text = "";
        }
    }
}