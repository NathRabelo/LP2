﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numQtdFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.grbSexo = new System.Windows.Forms.GroupBox();
            this.radM = new System.Windows.Forms.RadioButton();
            this.radF = new System.Windows.Forms.RadioButton();
            this.grbEstadoCivil = new System.Windows.Forms.GroupBox();
            this.radSolteiro = new System.Windows.Forms.RadioButton();
            this.radCasado = new System.Windows.Forms.RadioButton();
            this.grbDescontos = new System.Windows.Forms.GroupBox();
            this.btnNovaConsulta = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.txtDescontoIrpf = new System.Windows.Forms.TextBox();
            this.txtDescontoInss = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtSalFamila = new System.Windows.Forms.TextBox();
            this.txtAliquotaIrpf = new System.Windows.Forms.TextBox();
            this.txtAliquotaInss = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numQtdFilhos)).BeginInit();
            this.grbSexo.SuspendLayout();
            this.grbEstadoCivil.SuspendLayout();
            this.grbDescontos.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome do Funcionário:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Salário bruto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(12, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantidade de filhos:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // numQtdFilhos
            // 
            this.numQtdFilhos.Location = new System.Drawing.Point(142, 81);
            this.numQtdFilhos.Name = "numQtdFilhos";
            this.numQtdFilhos.Size = new System.Drawing.Size(48, 23);
            this.numQtdFilhos.TabIndex = 3;
            // 
            // mskSalBruto
            // 
            this.mskSalBruto.Location = new System.Drawing.Point(142, 53);
            this.mskSalBruto.Mask = "9999.99";
            this.mskSalBruto.Name = "mskSalBruto";
            this.mskSalBruto.Size = new System.Drawing.Size(107, 23);
            this.mskSalBruto.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(142, 24);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(141, 23);
            this.txtNome.TabIndex = 5;
            // 
            // grbSexo
            // 
            this.grbSexo.Controls.Add(this.radM);
            this.grbSexo.Controls.Add(this.radF);
            this.grbSexo.Location = new System.Drawing.Point(363, 24);
            this.grbSexo.Name = "grbSexo";
            this.grbSexo.Size = new System.Drawing.Size(200, 52);
            this.grbSexo.TabIndex = 6;
            this.grbSexo.TabStop = false;
            this.grbSexo.Text = "SEXO:";
            // 
            // radM
            // 
            this.radM.AutoSize = true;
            this.radM.Location = new System.Drawing.Point(109, 23);
            this.radM.Name = "radM";
            this.radM.Size = new System.Drawing.Size(80, 19);
            this.radM.TabIndex = 1;
            this.radM.Text = "Masculino";
            this.radM.UseVisualStyleBackColor = true;
            // 
            // radF
            // 
            this.radF.AutoSize = true;
            this.radF.Checked = true;
            this.radF.Location = new System.Drawing.Point(17, 23);
            this.radF.Name = "radF";
            this.radF.Size = new System.Drawing.Size(75, 19);
            this.radF.TabIndex = 0;
            this.radF.TabStop = true;
            this.radF.Text = "Feminino";
            this.radF.UseVisualStyleBackColor = true;
            // 
            // grbEstadoCivil
            // 
            this.grbEstadoCivil.Controls.Add(this.radSolteiro);
            this.grbEstadoCivil.Controls.Add(this.radCasado);
            this.grbEstadoCivil.Location = new System.Drawing.Point(363, 83);
            this.grbEstadoCivil.Name = "grbEstadoCivil";
            this.grbEstadoCivil.Size = new System.Drawing.Size(200, 84);
            this.grbEstadoCivil.TabIndex = 7;
            this.grbEstadoCivil.TabStop = false;
            this.grbEstadoCivil.Text = "EstadoCivil";
            // 
            // radSolteiro
            // 
            this.radSolteiro.AutoSize = true;
            this.radSolteiro.Location = new System.Drawing.Point(109, 39);
            this.radSolteiro.Name = "radSolteiro";
            this.radSolteiro.Size = new System.Drawing.Size(65, 19);
            this.radSolteiro.TabIndex = 2;
            this.radSolteiro.Text = "Solteiro";
            this.radSolteiro.UseVisualStyleBackColor = true;
            // 
            // radCasado
            // 
            this.radCasado.AutoSize = true;
            this.radCasado.Checked = true;
            this.radCasado.Location = new System.Drawing.Point(17, 39);
            this.radCasado.Name = "radCasado";
            this.radCasado.Size = new System.Drawing.Size(64, 19);
            this.radCasado.TabIndex = 1;
            this.radCasado.TabStop = true;
            this.radCasado.Text = "Casado";
            this.radCasado.UseVisualStyleBackColor = true;
            // 
            // grbDescontos
            // 
            this.grbDescontos.Controls.Add(this.btnNovaConsulta);
            this.grbDescontos.Controls.Add(this.lblDados);
            this.grbDescontos.Controls.Add(this.txtDescontoIrpf);
            this.grbDescontos.Controls.Add(this.txtDescontoInss);
            this.grbDescontos.Controls.Add(this.label9);
            this.grbDescontos.Controls.Add(this.label8);
            this.grbDescontos.Controls.Add(this.txtSalLiquido);
            this.grbDescontos.Controls.Add(this.txtSalFamila);
            this.grbDescontos.Controls.Add(this.txtAliquotaIrpf);
            this.grbDescontos.Controls.Add(this.txtAliquotaInss);
            this.grbDescontos.Controls.Add(this.label7);
            this.grbDescontos.Controls.Add(this.label6);
            this.grbDescontos.Controls.Add(this.label5);
            this.grbDescontos.Controls.Add(this.label4);
            this.grbDescontos.Location = new System.Drawing.Point(6, 173);
            this.grbDescontos.Name = "grbDescontos";
            this.grbDescontos.Size = new System.Drawing.Size(579, 190);
            this.grbDescontos.TabIndex = 8;
            this.grbDescontos.TabStop = false;
            this.grbDescontos.Text = "Descontos";
            this.grbDescontos.Visible = false;
            // 
            // btnNovaConsulta
            // 
            this.btnNovaConsulta.BackColor = System.Drawing.Color.Salmon;
            this.btnNovaConsulta.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnNovaConsulta.Location = new System.Drawing.Point(395, 135);
            this.btnNovaConsulta.Name = "btnNovaConsulta";
            this.btnNovaConsulta.Size = new System.Drawing.Size(118, 37);
            this.btnNovaConsulta.TabIndex = 11;
            this.btnNovaConsulta.Text = "NOVA CONSULTA";
            this.btnNovaConsulta.UseVisualStyleBackColor = false;
            this.btnNovaConsulta.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.Color.RosyBrown;
            this.lblDados.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDados.Location = new System.Drawing.Point(0, 170);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(54, 17);
            this.lblDados.TabIndex = 13;
            this.lblDados.Text = "DADOS";
            // 
            // txtDescontoIrpf
            // 
            this.txtDescontoIrpf.Location = new System.Drawing.Point(395, 57);
            this.txtDescontoIrpf.Name = "txtDescontoIrpf";
            this.txtDescontoIrpf.ReadOnly = true;
            this.txtDescontoIrpf.Size = new System.Drawing.Size(100, 23);
            this.txtDescontoIrpf.TabIndex = 12;
            // 
            // txtDescontoInss
            // 
            this.txtDescontoInss.Location = new System.Drawing.Point(395, 27);
            this.txtDescontoInss.Name = "txtDescontoInss";
            this.txtDescontoInss.ReadOnly = true;
            this.txtDescontoInss.Size = new System.Drawing.Size(100, 23);
            this.txtDescontoInss.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(287, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 17);
            this.label9.TabIndex = 10;
            this.label9.Text = "Desconto IRPF:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(287, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "Desconto INSS:";
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(120, 129);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.ReadOnly = true;
            this.txtSalLiquido.Size = new System.Drawing.Size(100, 23);
            this.txtSalLiquido.TabIndex = 8;
            // 
            // txtSalFamila
            // 
            this.txtSalFamila.Location = new System.Drawing.Point(120, 94);
            this.txtSalFamila.Name = "txtSalFamila";
            this.txtSalFamila.ReadOnly = true;
            this.txtSalFamila.Size = new System.Drawing.Size(100, 23);
            this.txtSalFamila.TabIndex = 7;
            // 
            // txtAliquotaIrpf
            // 
            this.txtAliquotaIrpf.Location = new System.Drawing.Point(120, 60);
            this.txtAliquotaIrpf.Name = "txtAliquotaIrpf";
            this.txtAliquotaIrpf.ReadOnly = true;
            this.txtAliquotaIrpf.Size = new System.Drawing.Size(100, 23);
            this.txtAliquotaIrpf.TabIndex = 6;
            // 
            // txtAliquotaInss
            // 
            this.txtAliquotaInss.Location = new System.Drawing.Point(120, 27);
            this.txtAliquotaInss.Name = "txtAliquotaInss";
            this.txtAliquotaInss.ReadOnly = true;
            this.txtAliquotaInss.Size = new System.Drawing.Size(100, 23);
            this.txtAliquotaInss.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(17, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "Salário Liquído:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(17, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Salário Família:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(16, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Aliquota IRPF:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(16, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Aliquota INSS:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnVerificar
            // 
            this.btnVerificar.BackColor = System.Drawing.Color.LightGreen;
            this.btnVerificar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnVerificar.Location = new System.Drawing.Point(18, 122);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(172, 45);
            this.btnVerificar.TabIndex = 9;
            this.btnVerificar.Text = "VERIFICAR DESCONTOS";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Salmon;
            this.btnSair.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSair.Location = new System.Drawing.Point(196, 122);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(139, 45);
            this.btnSair.TabIndex = 10;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 376);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.grbDescontos);
            this.Controls.Add(this.grbEstadoCivil);
            this.Controls.Add(this.grbSexo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.mskSalBruto);
            this.Controls.Add(this.numQtdFilhos);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Nathalia Rabelo";
            ((System.ComponentModel.ISupportInitialize)(this.numQtdFilhos)).EndInit();
            this.grbSexo.ResumeLayout(false);
            this.grbSexo.PerformLayout();
            this.grbEstadoCivil.ResumeLayout(false);
            this.grbEstadoCivil.PerformLayout();
            this.grbDescontos.ResumeLayout(false);
            this.grbDescontos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private NumericUpDown numQtdFilhos;
        private MaskedTextBox mskSalBruto;
        private TextBox txtNome;
        private GroupBox grbSexo;
        private RadioButton radM;
        private RadioButton radF;
        private GroupBox grbEstadoCivil;
        private RadioButton radSolteiro;
        private RadioButton radCasado;
        private GroupBox grbDescontos;
        private Label label4;
        private Button btnVerificar;
        private Button btnSair;
        private Label lblDados;
        private TextBox txtDescontoIrpf;
        private TextBox txtDescontoInss;
        private Label label9;
        private Label label8;
        private TextBox txtSalLiquido;
        private TextBox txtSalFamila;
        private TextBox txtAliquotaIrpf;
        private TextBox txtAliquotaInss;
        private Label label7;
        private Label label6;
        private Label label5;
        private Button btnNovaConsulta;
    }
}