﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc2
{
    public partial class Form1 : Form
    {
        double peso, altura, imc; 
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            peso   = Convert.ToDouble(txtPeso.Text);
            altura = Convert.ToDouble(txtAltura.Text);

            try{
                    imc = peso / (altura * altura);
                    txtImc.Text = imc.ToString("N1");

                if (imc < 18.5){

                    MessageBox.Show("MAGREZA");
                
                }else if (imc >= 18.5 && imc < 24.9){

                    MessageBox.Show("NORMAL");

                }else if(imc >= 25 && imc < 29.9){

                    MessageBox.Show("SOBREPESO");

                }else if(imc >=30 && imc <= 39.9){

                     MessageBox.Show("OBESIDADE");

                }else if(imc >= 40){

                     MessageBox.Show("OBESIDADE GRAVE");

                }
            }
    catch(FormatException){
        MessageBox.Show("Você informou valores inválidos, tente novamente!");
    }       
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text   = "";
            txtImc.Text    = "";
        }
    }
}
