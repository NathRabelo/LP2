﻿namespace CalculadoraNathaliaARabelo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblOperacao = new System.Windows.Forms.Label();
            this.lblOperacaoo = new System.Windows.Forms.Label();
            this.btn7 = new System.Windows.Forms.Button();
            this.btnCe = new System.Windows.Forms.Button();
            this.btnMais = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btnMult = new System.Windows.Forms.Button();
            this.btnResultado = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnPonto = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(12, 12);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(308, 23);
            this.txtResultado.TabIndex = 0;
            this.txtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblOperacao
            // 
            this.lblOperacao.AutoSize = true;
            this.lblOperacao.BackColor = System.Drawing.Color.White;
            this.lblOperacao.Location = new System.Drawing.Point(22, 20);
            this.lblOperacao.Name = "lblOperacao";
            this.lblOperacao.Size = new System.Drawing.Size(0, 15);
            this.lblOperacao.TabIndex = 1;
            // 
            // lblOperacaoo
            // 
            this.lblOperacaoo.AutoSize = true;
            this.lblOperacaoo.Location = new System.Drawing.Point(12, 15);
            this.lblOperacaoo.Name = "lblOperacaoo";
            this.lblOperacaoo.Size = new System.Drawing.Size(0, 15);
            this.lblOperacaoo.TabIndex = 2;
            this.lblOperacaoo.Click += new System.EventHandler(this.lblOperacaoo_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(22, 57);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(57, 47);
            this.btn7.TabIndex = 3;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btnCe
            // 
            this.btnCe.Location = new System.Drawing.Point(266, 57);
            this.btnCe.Name = "btnCe";
            this.btnCe.Size = new System.Drawing.Size(54, 47);
            this.btnCe.TabIndex = 5;
            this.btnCe.Text = "CE";
            this.btnCe.UseVisualStyleBackColor = true;
            this.btnCe.Click += new System.EventHandler(this.btnCe_Click);
            // 
            // btnMais
            // 
            this.btnMais.Location = new System.Drawing.Point(207, 57);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(50, 47);
            this.btnMais.TabIndex = 6;
            this.btnMais.Text = "+";
            this.btnMais.UseVisualStyleBackColor = true;
            this.btnMais.Click += new System.EventHandler(this.btnMais_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(147, 57);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(54, 47);
            this.btn9.TabIndex = 7;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(85, 57);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(56, 47);
            this.btn8.TabIndex = 8;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(85, 166);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(56, 47);
            this.btn2.TabIndex = 13;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(147, 166);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(54, 47);
            this.btn3.TabIndex = 12;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btnMult
            // 
            this.btnMult.Location = new System.Drawing.Point(207, 166);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(50, 47);
            this.btnMult.TabIndex = 11;
            this.btnMult.Text = "X";
            this.btnMult.UseVisualStyleBackColor = true;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            // 
            // btnResultado
            // 
            this.btnResultado.Location = new System.Drawing.Point(266, 166);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(54, 100);
            this.btnResultado.TabIndex = 10;
            this.btnResultado.Text = "=";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(22, 166);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(57, 47);
            this.btn1.TabIndex = 9;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btnPonto
            // 
            this.btnPonto.Location = new System.Drawing.Point(147, 219);
            this.btnPonto.Name = "btnPonto";
            this.btnPonto.Size = new System.Drawing.Size(54, 47);
            this.btnPonto.TabIndex = 17;
            this.btnPonto.Text = ",";
            this.btnPonto.UseVisualStyleBackColor = true;
            // 
            // btnDiv
            // 
            this.btnDiv.Location = new System.Drawing.Point(207, 219);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(50, 47);
            this.btnDiv.TabIndex = 16;
            this.btnDiv.Text = "/";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(22, 219);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(119, 47);
            this.btn0.TabIndex = 14;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(85, 113);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(56, 47);
            this.btn5.TabIndex = 23;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(147, 113);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(54, 47);
            this.btn6.TabIndex = 22;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btnMenos
            // 
            this.btnMenos.Location = new System.Drawing.Point(207, 113);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(50, 47);
            this.btnMenos.TabIndex = 21;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = true;
            this.btnMenos.Click += new System.EventHandler(this.btnMenos_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(266, 113);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(54, 47);
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "C";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(22, 113);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(57, 47);
            this.btn4.TabIndex = 19;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Red;
            this.btnSair.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSair.Location = new System.Drawing.Point(22, 279);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(298, 30);
            this.btnSair.TabIndex = 24;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(337, 321);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btnPonto);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btnMult);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.btnCe);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.lblOperacaoo);
            this.Controls.Add(this.lblOperacao);
            this.Controls.Add(this.txtResultado);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtResultado;
        private Label lblOperacao;
        private Label lblOperacaoo;
        private Button btn7;
        private Button btnCe;
        private Button btnMais;
        private Button btn9;
        private Button btn8;
        private Button btn2;
        private Button btn3;
        private Button btnMult;
        private Button btnResultado;
        private Button btn1;
        private Button btnPonto;
        private Button btnDiv;
        private Button btn0;
        private Button btn5;
        private Button btn6;
        private Button btnMenos;
        private Button btnClear;
        private Button btn4;
        private Button btnSair;
    }
}