using System.Globalization;

namespace CalculadoraNathaliaARabelo
{
    public partial class Form1 : Form
    {
        int valor1 = 0, valor2 = 0;
        string operacao;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblOperacaoo_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "0";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "9";
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            valor2 = int.Parse(txtResultado.Text, CultureInfo.InvariantCulture);

            if(operacao == "SOMA")
            {
                txtResultado.Text = Convert.ToString(valor1 + valor2);
            }else if(operacao == "SUB")
            {
                txtResultado.Text = Convert.ToString(valor1 - valor2);

            }else if (operacao == "MULT")
            {
                txtResultado.Text = Convert.ToString(valor1 * valor2);

            }else if (operacao == "DIV")
            {
                txtResultado.Text = Convert.ToString(valor1 / valor2);

            }
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            valor1 = int.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "SUB";
            lblOperacaoo.Text = "-";
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            valor1 = int.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "MULT";
            lblOperacaoo.Text = "X";
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            valor1 = int.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "DIV";
            lblOperacaoo.Text = "/";
        }

        private void btnCe_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";
            valor1 = 0;
            valor2 = 0;
            lblOperacaoo.Text = "";
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            //Para converter corretamente com os .
            valor1 = int.Parse(txtResultado.Text, CultureInfo.InvariantCulture);
            txtResultado.Text = "";
            operacao = "SOMA";
            lblOperacaoo.Text = "+";


        }
    }
}